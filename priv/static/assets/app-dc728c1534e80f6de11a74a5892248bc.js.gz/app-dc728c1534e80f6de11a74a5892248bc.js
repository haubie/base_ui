(()=>{function n(o){var t=window.document.getElementById(o);t.scrollIntoView({behavior:"smooth",block:"nearest",inline:"nearest"})}var e={scrollCarousel:n};window.baseui=e;})();
